# setup.py
from setuptools import setup

setup(
    name='imitation_learning',
    version='v1.0',
    packages=['imitation_learning'],
)
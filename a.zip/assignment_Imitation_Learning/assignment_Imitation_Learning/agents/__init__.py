#init for making folder a package
